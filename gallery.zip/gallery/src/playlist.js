export const playlist = [
  "assets/sound/zhana_whos_y2k_ my y2k _( _3 ily.mp3",
];
